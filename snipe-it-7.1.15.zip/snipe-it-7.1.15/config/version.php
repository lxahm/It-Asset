<?php
return array (
  'app_version' => 'v7.1.15',
  'full_app_version' => 'v7.1.15 - build 16052-g25bfd3e84',
  'build_version' => '16052',
  'prerelease_version' => '',
  'hash_version' => 'g25bfd3e84',
  'full_hash' => 'v7.1.15-105-g25bfd3e84',
  'branch' => 'master',
);